het initieel aanleveren van Gemeentestad (Omgevingsplan Zaltbommel).
v1.0.6 is gepubliceerd aangezien in v1.0.5 abusievelijk het SymbolisatieItem ontbrak in het manifest.
