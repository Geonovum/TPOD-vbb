Voorbeeldbestand omgevingsplan Gemeentestad v1.0.5 is gebaseerd op de IMOW-schema's v1.0.3 en STOP-schema's v1.0.4.

Het Gemeentestad-voorbeeld is door de keten gehaald met de volgende wijzigingen ten opzichte van v1.0.4:
- LijstAanhef verwijderd
- Datums aangepast voor een logische flow
- Identificaties (FRBRExpressions) meer in lijn met STOP aanbevelingen
