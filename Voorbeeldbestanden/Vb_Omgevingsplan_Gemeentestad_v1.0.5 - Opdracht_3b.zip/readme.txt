Dit is de eerste mutatie die door de DSO-keten is gekomen. 
Het betreft het wijzigen van artikel 2.10 waarbij kantoor hernoemd wordt naar kantoorruimte. 
Dit wordt ook aangepast in de naam van de activiteit.