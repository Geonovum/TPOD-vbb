# Voorbeeldbestand omgevingsvisie Leiden v1.0.0

xml_omgevingsvisie_Leiden_1.0

Dit bestand is gebaseerd op STOP-versie 1.0.3 en IMOW-versie 1.0.2. 

Omgevingsvisie Leiden is opgezet om stapsgewijs de effecten van ontwerpkeuzen uit te testen in de bekendmaking en de dso-viewer. 
In deze stap is de tekststructuur uitgewerkt en zijn een vijftal GIO's aan de tekst toegevoegd. 
In de volgende stap zullen de locaties worden toegevoegd t.b.v. de dso-viewer en wordt de ontwerpkeuze thema en/of hoofdlijn uitgewerkt.

Het document is technisch van aard en inhoudelijk niet representatief voor de uiteindelijke Omgevingsvisie Leiden.