Het intrekken en vervangen van Gemeentestad (Omgevingsplan Zaltbommel).
Bij het intrekken en vervangen wordt de Regeling en diens GIO's ingetrokken en vervangen voor een nieuwe Regeling met een nieuwe reeks GIO's.
De OW-annotaties van Gemeentestad hebben één inhoudelijke wijziging t.o.v. het origineel (een cultuuractiviteit).
De Regeltekstobjecten worden allemaal aangeleverd, zodat het DSO-LV weet dat deze hangen aan een nieuwe regeling.