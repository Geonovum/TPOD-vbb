Een wijzigingsbesluit waarbij een artikel wordt toegevoegd, inclusief OW-Regeltekst-object. 
Dit is het functioneel minst logische voorbeeld, maar was technisch noodzakelijk om aan te kunnen tonen dat de keten wel klaar is om een nieuw artikel te kunnen ontvangen. 
De inhoud van het toegevoegde artikel 1.5 is dan ook “Dit is een enkele regeltekstaanlevering.”