Dit is een setje waarmee afbreek-functionaliteit wordt getoond.
In 3a wordt een initieel besluit aangeleverd.
In 3b wordt een wijziging op het initiële besluit aangeleverd.
In 3c wordt een afbreekOpdracht gestuurd t.o.v. de wijziging uit 3b. 
Hiermee wordt het gehele wijzigingsbesluit afgebroken.